package restaurant;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ServerB extends Email { // Inheritance used#############

	static Kitchen kitc;
	int orders = 0;
	JComboBox<Object> kpComboBox = new JComboBox<Object>();
	JComboBox<Object> soupComboBox = new JComboBox<Object>();
	JComboBox<Object> emComboBox = new JComboBox<Object>();
	JComboBox<Object> csrComboBox = new JComboBox<Object>();
	JComboBox<Object> gmComboBox = new JComboBox<Object>();
	JComboBox<Object> ccsComboBox = new JComboBox<Object>();

	JComboBox<Object> hbbComboBox = new JComboBox<Object>();
	JComboBox<Object> rotdComboBox = new JComboBox<Object>();
	JComboBox<Object> csComboBox = new JComboBox<Object>();
	JComboBox<Object> ssComboBox = new JComboBox<Object>();
	JComboBox<Object> ccppComboBox = new JComboBox<Object>();
	JComboBox<Object> vsfComboBox = new JComboBox<Object>();

	JComboBox<Object> wcfComboBox = new JComboBox<Object>();
	JComboBox<Object> atComboBox = new JComboBox<Object>();
	JComboBox<Object> bbpComboBox = new JComboBox<Object>();
	JComboBox<Object> blbcComboBox = new JComboBox<Object>();
	JComboBox<Object> stdpComboBox = new JComboBox<Object>();
	JComboBox<Object> citComboBox = new JComboBox<Object>();
	JLabel kitstatus = new JLabel("Kitchen Closed");

	JTextArea ordersum = new JTextArea(10, 10);
	JScrollPane scrollorder = new JScrollPane(ordersum);
	double total = 0.00;
	JTextField textsum = new JTextField(10);
	JTextArea comments = new JTextArea(5, 5);
	JButton food = new JButton("Order Food");

	JLabel monday = new JLabel("Monday Night");
	JLabel monband = new JLabel("The 4 J's");
	JLabel tuesday = new JLabel("Tuesday Night");
	JLabel tuesband = new JLabel("Rock of Ages");
	JLabel wednesday = new JLabel("Wednesday Night");
	JLabel wedband = new JLabel("Rusty Springs");
	JLabel thursday = new JLabel("Thursday Night");
	JLabel thursband = new JLabel("Away with the Fairies");
	JLabel friday = new JLabel("Friday Night");
	JLabel friband = new JLabel("Ruaille Buaille");
	JLabel saturday = new JLabel("Saturday Night");
	JLabel satband = new JLabel("The Rockets");
	JLabel sunday = new JLabel("Sunday Night");
	JLabel sunband = new JLabel("Ger Long");
	JPanel bands = new JPanel(new FlowLayout());
	Box days = new Box(BoxLayout.Y_AXIS);
	Box band = new Box(BoxLayout.Y_AXIS);

	public ServerB() {
		JFrame frame = new JFrame();
		frame.setTitle("Table 2");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		final CardLayout cards = new CardLayout();
		final JPanel cardz1 = new JPanel();
		cardz1.setLayout(cards);

		// Order Screen/////////////////////////////////////////////////

		JPanel pg1 = new JPanel();
		pg1.setLayout(new BorderLayout());
		JPanel welpan = new JPanel();
		welpan.setLayout(new FlowLayout());
		JLabel welcome = new JLabel("Welcome to the Old Mill");
		welpan.add(welcome);
		pg1.add(welpan, BorderLayout.NORTH);
		JPanel butpan = new JPanel();
		butpan.setLayout(new FlowLayout());
		kitstatus.setVisible(false);
		butpan.add(kitstatus);
		butpan.add(food);

		pg1.add(butpan, BorderLayout.CENTER);
		JPanel bottom = new JPanel(new BorderLayout());
		JPanel media = new JPanel();
		media.setLayout(new GridLayout(2, 1));
		JLabel facebook = new JLabel("Come like our Facebook page at : TheOldMill Restaurant");
		JLabel twitter = new JLabel("Come follow us on Twitter at : @fancysawdust");
		media.add(facebook);
		media.add(twitter);
		bottom.add(media, BorderLayout.NORTH);
		JButton emailus = new JButton("Any Comments? Email us here");
		bottom.add(emailus, BorderLayout.CENTER);

		JPanel southp = new JPanel(new BorderLayout());
		southp.add(bottom, BorderLayout.SOUTH);
		Font fontn = new Font("Bookman Old Style", Font.PLAIN, 16);
		JLabel news = new JLabel("This Weeknight's Entertainment");
		news.setFont(fontn);
		southp.add(news, BorderLayout.NORTH);
		news.setHorizontalAlignment(JLabel.CENTER);

		pg1.add(southp, BorderLayout.SOUTH);

		days.add(monday);
		band.add(monband);
		days.add(tuesday);
		band.add(tuesband);
		days.add(wednesday);
		band.add(wedband);
		days.add(thursday);
		band.add(thursband);
		days.add(friday);
		band.add(friband);
		days.add(saturday);
		band.add(satband);
		days.add(sunday);
		band.add(sunband);
		bands.add(days);
		bands.add(band);
		southp.add(bands, BorderLayout.CENTER);
		ActionListener fooda = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cards.show(cardz1, "FoodScreen");
			}
		};

		food.addActionListener(fooda);
		bands.setBackground(new Color(136, 208, 247));
		media.setBackground(new Color(0, 0, 0));
		facebook.setForeground(new Color(255, 255, 255));
		twitter.setForeground(new Color(255, 255, 255));
		Font fontw = new Font("Bookman Old Style", Font.BOLD, 20);
		welcome.setFont(fontw);
		welcome.setForeground(Color.white);
		welpan.setBackground(new Color(0, 0, 0));
		news.setForeground(Color.white);
		southp.setBackground(new Color(0, 0, 0));
		butpan.setBackground(new Color(136, 208, 247));
		cardz1.add(pg1, "WelcomeScreen");
		///////////////////////////////////////////////////////////
		JPanel email = new JPanel(new BorderLayout());
		JLabel etopl = new JLabel("Email Us", 0);
		etopl.setFont(new Font("Serif", Font.BOLD, 25));
		email.add(etopl, BorderLayout.NORTH);
		JPanel namep = new JPanel(new BorderLayout());
		JLabel entname = new JLabel("Enter your name here: ");
		JTextField textname = new JTextField(10);
		namep.add(entname, BorderLayout.WEST);
		namep.add(textname, BorderLayout.CENTER);
		Box box1 = new Box(BoxLayout.Y_AXIS);
		box1.add(namep);
		JPanel emailpan = new JPanel(new BorderLayout());
		JLabel emaill = new JLabel("Enter your email here: ");
		JTextField emailtext = new JTextField(10);
		emailpan.add(emaill, BorderLayout.WEST);
		emailpan.add(emailtext, BorderLayout.CENTER);
		box1.add(emailpan);
		JLabel messlab = new JLabel("Enter your Message Below:");
		messlab.setFont(new Font("Bookman Old Style", Font.PLAIN, 18));
		box1.add(messlab);
		JTextArea jta1 = new JTextArea(10, 10);
		JScrollPane scroll1 = new JScrollPane(jta1);
		box1.add(scroll1);
		email.add(box1, BorderLayout.CENTER);
		JButton exitb = new JButton("Back");
		JButton sendemail = new JButton("Send Message");
		JPanel sendpan = new JPanel(new FlowLayout());
		sendpan.add(exitb);
		sendpan.add(sendemail);
		box1.add(sendpan);
		ActionListener sendact = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ans = JOptionPane.showConfirmDialog(frame, "Are you sure you would like to send?", "Important",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					if (!textname.getText().equals("")) {
						if (!emailtext.getText().equals("")) {
							if (!jta1.getText().equals("")) {
								String subject1 = "Customer Email: " + textname.getText();
								String body1 = jta1.getText().trim() + "\n" + textname.getText() + "\n"
										+ emailtext.getText();
								SendEmail(subject1, body1);
								JOptionPane.showMessageDialog(null, "Your message has be sent", "Confirmation",
										JOptionPane.INFORMATION_MESSAGE);
								cards.show(cardz1, "WelcomeScreen");
							} else {
								JOptionPane.showMessageDialog(null, "Please enter a message", "Alert",
										JOptionPane.INFORMATION_MESSAGE);
							}
						} else {
							JOptionPane.showMessageDialog(null, "Please enter your email", "Alert",
									JOptionPane.INFORMATION_MESSAGE);
						}
					} else {
						JOptionPane.showMessageDialog(null, "Please enter your name", "Alert",
								JOptionPane.INFORMATION_MESSAGE);
					}
				}
			}
		};

		sendemail.addActionListener(sendact);
		ActionListener backact = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ans = JOptionPane.showConfirmDialog(frame,
						"Are you sure you would like to go back without sending?", "Important",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					textname.setText("");
					emailtext.setText("");
					jta1.setText("");
					cards.show(cardz1, "WelcomeScreen");
				}
			}
		};

		exitb.addActionListener(backact);
		cardz1.add(email, "Email");
		ActionListener emailact = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cards.show(cardz1, "Email");
			}
		};

		emailus.addActionListener(emailact);
		// Food Screen/////////////////////////////////////////////
		JPanel pg2 = new JPanel();
		pg2.setLayout(new BorderLayout());
		JTabbedPane jtp = new JTabbedPane();

		// Starters////////////////////////////////////////////////
		JPanel starters = new JPanel(new BorderLayout());
		JPanel st = new JPanel(new BorderLayout());
		Font font = new Font("Serif", Font.PLAIN, 12);
		Font smallf = new Font("Cambria Bold", Font.PLAIN, 16);

		JLabel kp = new JLabel("King Prawns - - - - - - - �4.95");
		kp.setFont(smallf);
		JLabel kpd = new JLabel("Wrapped in filo pastry. Served with a sweet chilli dip\n");
		kpd.setFont(font);

		kpComboBox.addItem("0");
		kpComboBox.addItem("1");
		kpComboBox.addItem("2");
		kpComboBox.addItem("3");
		kpComboBox.addItem("4");

		JLabel soup = new JLabel("Soup Of The Day - - - - - - - �4.95");
		soup.setFont(smallf);
		JLabel soupd = new JLabel("With homemade brown bread");
		soupd.setFont(font);

		soupComboBox.addItem("0");
		soupComboBox.addItem("1");
		soupComboBox.addItem("2");
		soupComboBox.addItem("3");
		soupComboBox.addItem("4");

		JLabel em = new JLabel("Egg Mayonnaise - - - - - - - �4.95");
		em.setFont(smallf);
		JLabel emd = new JLabel(
				"Egg served on a bed of tossed salad, coleslaw topped with Marie-Rose sauce served with brown bread to the side  ");
		emd.setFont(font);

		emComboBox.addItem("0");
		emComboBox.addItem("1");
		emComboBox.addItem("2");
		emComboBox.addItem("3");
		emComboBox.addItem("4");

		JLabel csr = new JLabel("Chicken Spring Roll - - - - - - - �4.95");
		csr.setFont(smallf);
		JLabel csrd = new JLabel("Crispy spring roll served with sweet and sour sauce on a bed of tossed salad");
		csrd.setFont(font);

		csrComboBox.addItem("0");
		csrComboBox.addItem("1");
		csrComboBox.addItem("2");
		csrComboBox.addItem("3");
		csrComboBox.addItem("4");

		JLabel gm = new JLabel("Garlic Mushrooms - - - - - - - �4.95");
		gm.setFont(smallf);
		JLabel gmd = new JLabel("Served on a bed of tossed salad with garlic dip");
		gmd.setFont(font);

		gmComboBox.addItem("0");
		gmComboBox.addItem("1");
		gmComboBox.addItem("2");
		gmComboBox.addItem("3");
		gmComboBox.addItem("4");

		JLabel ccs = new JLabel("Classic Caesar Salad - - - - - - - �4.95");
		ccs.setFont(smallf);
		JLabel ccsd = new JLabel(
				"Mixed lettuce leaves topped with warm crispy bacon, croutons, parmesan cheese, pine nuts and caesar dressing");
		ccsd.setFont(font);

		ccsComboBox.addItem("0");
		ccsComboBox.addItem("1");
		ccsComboBox.addItem("2");
		ccsComboBox.addItem("3");
		ccsComboBox.addItem("4");

		JLabel space = new JLabel("\n");
		JLabel space1 = new JLabel("\n");
		JLabel space2 = new JLabel("\n");
		JLabel space3 = new JLabel("\n");
		JLabel space4 = new JLabel("\n");

		Box sl = new Box(BoxLayout.Y_AXIS);
		Box sr = new Box(BoxLayout.Y_AXIS);
		sl.add(kp);
		sl.add(kpd);
		sl.add(soup);
		sl.add(soupd);
		sl.add(em);
		sl.add(emd);
		sl.add(csr);
		sl.add(csrd);
		sl.add(gm);
		sl.add(gmd);
		sl.add(ccs);
		sl.add(ccsd);

		sr.add(kpComboBox);
		sr.add(space);
		sr.add(soupComboBox);
		sr.add(space1);
		sr.add(emComboBox);
		sr.add(space2);
		sr.add(csrComboBox);
		sr.add(space3);
		sr.add(gmComboBox);
		sr.add(space4);
		sr.add(ccsComboBox);

		JButton back1 = new JButton("Back");
		JButton next1 = new JButton("Next Page");
		ActionListener back1a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ans;
				ans = JOptionPane.showConfirmDialog(null, "Are you sure you want to quit ordering?", "Quit",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					cards.show(cardz1, "WelcomeScreen");
				}
			}
		};
		back1.addActionListener(back1a);

		ActionListener next1a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtp.setSelectedIndex(1);
			}
		};

		next1.addActionListener(next1a);
		JPanel stbottom = new JPanel(new GridLayout(1, 2));
		stbottom.add(back1);
		stbottom.add(next1);
		starters.add(stbottom, BorderLayout.SOUTH);

		st.add(sl, BorderLayout.CENTER);
		st.add(sr, BorderLayout.EAST);
		starters.add(st, BorderLayout.CENTER);
		ImageIcon startericon = new ImageIcon(this.getClass().getResource("salad-icon.png"));
		jtp.addTab("Starters", startericon, starters,
				"One day you're the best thing since sliced bread. The next, you're toast.");

		////////////////////////////////////////////////////////////////////////////////////

		// Mains////////////////////////////////////////////////
		JPanel maincourse = new JPanel(new BorderLayout());
		JPanel main = new JPanel(new BorderLayout());

		JLabel hbb = new JLabel("Homemade Beef Burger - - - - - - - �13.95");
		hbb.setFont(smallf);
		JLabel hbbd = new JLabel(
				"6oz burger topped with crispy bacon, egg, cheese and served with a side salad and chips");
		hbbd.setFont(font);

		hbbComboBox.addItem("0");
		hbbComboBox.addItem("1");
		hbbComboBox.addItem("2");
		hbbComboBox.addItem("3");
		hbbComboBox.addItem("4");

		JLabel rotd = new JLabel("Roast Of The Day - - - - - - - �11.95");
		rotd.setFont(smallf);
		JLabel rotdd = new JLabel("Served with potatos and vegetables");
		rotdd.setFont(font);

		rotdComboBox.addItem("0");
		rotdComboBox.addItem("1");
		rotdComboBox.addItem("2");
		rotdComboBox.addItem("3");
		rotdComboBox.addItem("4");

		JLabel cs = new JLabel("Chicken Supreme - - - - - - - �13.95");
		cs.setFont(smallf);
		JLabel csd = new JLabel(
				"Panfried breast of chicken served on two toasted baps topped with lettuce, tomato and mayo");
		csd.setFont(font);

		csComboBox.addItem("0");
		csComboBox.addItem("1");
		csComboBox.addItem("2");
		csComboBox.addItem("3");
		csComboBox.addItem("4");

		JLabel ss = new JLabel("Smoked Salmon - - - - - - - �12.95");
		ss.setFont(smallf);
		JLabel ssd = new JLabel("Served on a bed of salad, coleslaw and lemon, with brown bread to the side");
		ssd.setFont(font);

		ssComboBox.addItem("0");
		ssComboBox.addItem("1");
		ssComboBox.addItem("2");
		ssComboBox.addItem("3");
		ssComboBox.addItem("4");

		JLabel ccpp = new JLabel("Creamy Chicken Pesto Pasta - - - - - - - �11.95");
		ccpp.setFont(smallf);
		JLabel ccppd = new JLabel(
				"Chicken fillet, mushroom & onions served in a creamy pesto sauce on a bed of tagliatelle");
		ccppd.setFont(font);

		ccppComboBox.addItem("0");
		ccppComboBox.addItem("1");
		ccppComboBox.addItem("2");
		ccppComboBox.addItem("3");
		ccppComboBox.addItem("4");

		JLabel vsf = new JLabel("Vegetarian Stir Fry - - - - - - - �9.95");
		vsf.setFont(smallf);
		JLabel vsfd = new JLabel(
				"A selection of vegetables stir fried with sesame oil, soy sauce & sweet chilli sauce on a bed of rice");
		vsfd.setFont(font);

		vsfComboBox.addItem("0");
		vsfComboBox.addItem("1");
		vsfComboBox.addItem("2");
		vsfComboBox.addItem("3");
		vsfComboBox.addItem("4");

		JLabel space6 = new JLabel("\n");
		JLabel space7 = new JLabel("\n");
		JLabel space8 = new JLabel("\n");
		JLabel space9 = new JLabel("\n");
		JLabel space10 = new JLabel("\n");

		Box ml = new Box(BoxLayout.Y_AXIS);
		Box mr = new Box(BoxLayout.Y_AXIS);
		ml.add(hbb);
		ml.add(hbbd);
		ml.add(rotd);
		ml.add(rotdd);
		ml.add(cs);
		ml.add(csd);
		ml.add(ss);
		ml.add(ssd);
		ml.add(ccpp);
		ml.add(ccppd);
		ml.add(vsf);
		ml.add(vsfd);

		mr.add(hbbComboBox);
		mr.add(space6);
		mr.add(rotdComboBox);
		mr.add(space7);
		mr.add(csComboBox);
		mr.add(space8);
		mr.add(ssComboBox);
		mr.add(space9);
		mr.add(ccppComboBox);
		mr.add(space10);
		mr.add(vsfComboBox);

		JButton back2 = new JButton("Back");
		JButton next2 = new JButton("Next Page");
		ActionListener back2a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtp.setSelectedIndex(0);
			}
		};
		back2.addActionListener(back2a);

		ActionListener next2a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtp.setSelectedIndex(2);
			}
		};

		next2.addActionListener(next2a);
		JPanel mainbottom = new JPanel(new GridLayout(1, 2));
		mainbottom.add(back2);
		mainbottom.add(next2);
		maincourse.add(mainbottom, BorderLayout.SOUTH);

		main.add(ml, BorderLayout.CENTER);
		main.add(mr, BorderLayout.EAST);
		maincourse.add(main, BorderLayout.CENTER);
		ImageIcon mainicon = new ImageIcon(this.getClass().getResource("main-icon.png"));
		jtp.addTab("Main Course", mainicon, maincourse, "I am on a seafood diet. Every time I see food, I eat it");
		/////////////////////////////////////////////////////////////////////////////////////

		// Dessert////////////////////////////////////////////////
		JPanel dessert = new JPanel(new BorderLayout());
		JPanel des = new JPanel(new BorderLayout());

		JLabel wcf = new JLabel("Warm Chocolate Fondant - - - - - - - �4.95");
		wcf.setFont(smallf);
		JLabel wcfd = new JLabel("Served with Vanilla Pod Cream and Caramel Sauce");
		wcfd.setFont(font);

		wcfComboBox.addItem("0");
		wcfComboBox.addItem("1");
		wcfComboBox.addItem("2");
		wcfComboBox.addItem("3");
		wcfComboBox.addItem("4");

		JLabel at = new JLabel("Apple Tart - - - - - - - �4.95");
		at.setFont(smallf);
		JLabel atd = new JLabel("Served with Cinnamon Ice Cream");
		atd.setFont(font);

		atComboBox.addItem("0");
		atComboBox.addItem("1");
		atComboBox.addItem("2");
		atComboBox.addItem("3");
		atComboBox.addItem("4");

		JLabel bbp = new JLabel("Baked Baby Pineapple - - - - - - - �4.95");
		bbp.setFont(smallf);
		JLabel bbpd = new JLabel("Served with Tropical Fruit Glazed in a Marsala Sabayon");
		bbpd.setFont(font);

		bbpComboBox.addItem("0");
		bbpComboBox.addItem("1");
		bbpComboBox.addItem("2");
		bbpComboBox.addItem("3");
		bbpComboBox.addItem("4");

		JLabel blbc = new JLabel("Baked Lemon And Blueberry Cheesecake - - - - - - - �4.95");
		blbc.setFont(smallf);
		JLabel blbcd = new JLabel("Served with a blueberry sauce and creme chantilly");
		blbcd.setFont(font);

		blbcComboBox.addItem("0");
		blbcComboBox.addItem("1");
		blbcComboBox.addItem("2");
		blbcComboBox.addItem("3");
		blbcComboBox.addItem("4");

		JLabel stdp = new JLabel("Sticky Toffee And Date Pudding - - - - - - - �4.95");
		stdp.setFont(smallf);
		JLabel stdpd = new JLabel("Served with bushmills butterscotch sauce and cream");
		stdpd.setFont(font);

		stdpComboBox.addItem("0");
		stdpComboBox.addItem("1");
		stdpComboBox.addItem("2");
		stdpComboBox.addItem("3");
		stdpComboBox.addItem("4");

		JLabel cit = new JLabel("Classic Italian Tiramisu - - - - - - - �4.95");
		cit.setFont(smallf);
		JLabel citd = new JLabel("Served with marbled ice cream and chocolate sauce");
		citd.setFont(font);

		citComboBox.addItem("0");
		citComboBox.addItem("1");
		citComboBox.addItem("2");
		citComboBox.addItem("3");
		citComboBox.addItem("4");

		JLabel space11 = new JLabel("\n");
		JLabel space12 = new JLabel("\n");
		JLabel space13 = new JLabel("\n");
		JLabel space14 = new JLabel("\n");
		JLabel space15 = new JLabel("\n");

		Box dl = new Box(BoxLayout.Y_AXIS);
		Box dr = new Box(BoxLayout.Y_AXIS);
		dl.add(wcf);
		dl.add(wcfd);
		dl.add(at);
		dl.add(atd);
		dl.add(bbp);
		dl.add(bbpd);
		dl.add(blbc);
		dl.add(blbcd);
		dl.add(stdp);
		dl.add(stdpd);
		dl.add(cit);
		dl.add(citd);

		dr.add(wcfComboBox);
		dr.add(space11);
		dr.add(atComboBox);
		dr.add(space12);
		dr.add(bbpComboBox);
		dr.add(space13);
		dr.add(blbcComboBox);
		dr.add(space14);
		dr.add(stdpComboBox);
		dr.add(space15);
		dr.add(citComboBox);

		JButton back3 = new JButton("Back");
		JButton next3 = new JButton("Next Page");
		ActionListener back3a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtp.setSelectedIndex(1);
			}
		};
		back3.addActionListener(back3a);

		ActionListener next3a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				compileStarter();
				cards.show(cardz1, "summaryScreen");
				DecimalFormat df = new DecimalFormat("####0.00");
				textsum.setText("Your total is: �" + df.format(total));
			}
		};

		next3.addActionListener(next3a);
		JPanel desbottom = new JPanel(new GridLayout(1, 2));
		desbottom.add(back3);
		desbottom.add(next3);
		dessert.add(desbottom, BorderLayout.SOUTH);

		des.add(dl, BorderLayout.CENTER);
		des.add(dr, BorderLayout.EAST);
		dessert.add(des, BorderLayout.CENTER);
		ImageIcon desserticon = new ImageIcon(this.getClass().getResource("dessert-icon.png"));
		jtp.addTab("Dessert", desserticon, dessert, "A donkey fell into a bowl of sugar. Now that's a sweet ass");
		//////////////////////////////////////////////////////////////////

		// Summary///////////////////////////////////////
		JPanel summary = new JPanel();
		summary.setLayout(new BorderLayout());
		JPanel sumpan = new JPanel();
		sumpan.setLayout(new FlowLayout());
		JLabel sumlab = new JLabel("Your order summary is as follows");
		sumpan.add(sumlab);
		summary.add(sumpan, BorderLayout.NORTH);
		JPanel text = new JPanel(new BorderLayout());
		text.add(scrollorder, BorderLayout.NORTH);
		JPanel commentpan = new JPanel(new BorderLayout());
		JLabel com = new JLabel("Do you have any comments or special requests?");
		commentpan.add(com, BorderLayout.NORTH);
		JPanel compan1 = new JPanel(new BorderLayout());
		JPanel radpan = new JPanel(new GridLayout(1, 2));
		JRadioButton hide1 = new JRadioButton("No");
		JRadioButton show1 = new JRadioButton("Yes");
		ButtonGroup bg1 = new ButtonGroup();
		bg1.add(hide1);
		bg1.add(show1);
		radpan.add(hide1);
		radpan.add(show1);

		comments.setVisible(false);
		comments.setText("Please enter them here!");
		comments.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				comments.setText("");
			}

			public void focusLost(FocusEvent e) {
				// nothing
			}
		});
		compan1.add(comments, BorderLayout.CENTER);
		compan1.add(radpan, BorderLayout.NORTH);
		commentpan.add(compan1, BorderLayout.CENTER);
		text.add(commentpan, BorderLayout.CENTER);
		text.add(textsum, BorderLayout.SOUTH);
		summary.add(text, BorderLayout.CENTER);
		JPanel sumbutpan = new JPanel(new GridLayout(1, 2));
		JButton back4 = new JButton("Back");
		JButton next4 = new JButton("Send Order");
		sumbutpan.add(back4);
		sumbutpan.add(next4);
		summary.add(sumbutpan, BorderLayout.SOUTH);
		ActionListener show1a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comments.setVisible(true);
				frame.setSize(604, 500);
			}
		};
		ActionListener hide1a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comments.setVisible(false);
				frame.pack();
			}
		};
		show1.addActionListener(show1a);
		hide1.addActionListener(hide1a);

		ActionListener back4a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cards.show(cardz1, "FoodScreen");
				jtp.setSelectedIndex(2);
			}
		};
		back4.addActionListener(back4a);

		ActionListener next4a = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ans = JOptionPane.showConfirmDialog(frame, "Are you sure you would like to order?", "Important",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					String a = ordersum.getText();
					String b = comments.getText();
					kitc.sendTable2(a, b);
					try {
						String filename = "src/restaurant/Table_2.txt";
						FileWriter fw = new FileWriter(filename, true);
						if (b.equals("Please enter them here!"))
							b = "No Comments";
						DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
						Date date = new Date();
						String date1 = dateFormat.format(date);
						orders++;
						fw.write("\n" + date1 + " :: Order_" + orders + ":: Total = " + total + "  ::" + "\n" + a + "\n"
								+ b + "\n::");
						fw.close();
					} catch (IOException ioe) {
						/////////////////// BLANK FOR NOW///////////////
					}
					cards.show(cardz1, "WelcomeScreen");
					frame.pack();
				}
			}
		};

		next4.addActionListener(next4a);

		cardz1.add(summary, "summaryScreen");
		/////////////////////////////////////////////////////////////
		pg2.add(jtp, BorderLayout.CENTER);
		cardz1.add(pg2, "FoodScreen");

		cp.add(cardz1);
		frame.pack();

		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
		Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
		int x = (int) rect.getMaxX() - frame.getWidth();
		int y = 0;
		frame.setLocation(x, y);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void passkit(Kitchen kit) {
		kitc = kit;
	}

	public void compileStarter() {
		ordersum.setText("");
		if (kpComboBox.getSelectedItem() != "0") {
			ordersum.append("King Prawns --- x" + kpComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (kpComboBox.getSelectedIndex()));
		}
		if (soupComboBox.getSelectedItem() != "0") {
			ordersum.append("Soup of the Day --- x" + soupComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (soupComboBox.getSelectedIndex()));
		}
		if (emComboBox.getSelectedItem() != "0") {
			ordersum.append("Egg Mayonnaise --- x" + emComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (emComboBox.getSelectedIndex()));
		}
		if (csrComboBox.getSelectedItem() != "0") {
			ordersum.append("Chicken Spring Rolls --- x" + csrComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (csrComboBox.getSelectedIndex()));
		}
		if (gmComboBox.getSelectedItem() != "0") {
			ordersum.append("Garlic Mushrooms --- x" + gmComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (gmComboBox.getSelectedIndex()));
		}
		if (ccsComboBox.getSelectedItem() != "0") {
			ordersum.append("Classic Caesar Salad --- x" + ccsComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (ccsComboBox.getSelectedIndex()));
		}
		ordersum.append("------------------------\n");
		compileMain();
	}

	public void compileMain() {
		if (hbbComboBox.getSelectedItem() != "0") {
			ordersum.append("Homemade Beef Burger --- x" + hbbComboBox.getSelectedItem().toString() + "\n");
			total += 13.95 * (hbbComboBox.getSelectedIndex());
		}
		if (rotdComboBox.getSelectedItem() != "0") {
			ordersum.append("Roast of the Day --- x" + rotdComboBox.getSelectedItem().toString() + "\n");
			total += 11.95 * (rotdComboBox.getSelectedIndex());
		}
		if (csComboBox.getSelectedItem() != "0") {
			ordersum.append("Chicken Supreme --- x" + csComboBox.getSelectedItem().toString() + "\n");
			total += 13.95 * (csComboBox.getSelectedIndex());
		}
		if (ssComboBox.getSelectedItem() != "0") {
			ordersum.append("Smoked Salmon --- x" + ssComboBox.getSelectedItem().toString() + "\n");
			total += 12.95 * (ssComboBox.getSelectedIndex());
		}
		if (ccppComboBox.getSelectedItem() != "0") {
			ordersum.append("Creamy Chicken Pesto Pasta --- x" + ccppComboBox.getSelectedItem().toString() + "\n");
			total += 11.95 * (ccppComboBox.getSelectedIndex());
		}
		if (vsfComboBox.getSelectedItem() != "0") {
			ordersum.append("Vegetarian Stir Fry --- x" + vsfComboBox.getSelectedItem().toString() + "\n");
			total += 9.95 * (vsfComboBox.getSelectedIndex());
		}
		ordersum.append("------------------------\n");
		compileDessert();
	}

	public void compileDessert() {
		if (wcfComboBox.getSelectedItem() != "0") {
			ordersum.append("Warm Chocolate Fondant --- x" + wcfComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (wcfComboBox.getSelectedIndex()));
		}
		if (atComboBox.getSelectedItem() != "0") {
			ordersum.append("Apple Tart --- x" + atComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (atComboBox.getSelectedIndex()));
		}
		if (bbpComboBox.getSelectedItem() != "0") {
			ordersum.append("Baked Baby Pineapple --- x" + bbpComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (bbpComboBox.getSelectedIndex()));
		}
		if (blbcComboBox.getSelectedItem() != "0") {
			ordersum.append(
					"Baked Lemon And Blueberry Cheesecake --- x" + blbcComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (blbcComboBox.getSelectedIndex()));
		}
		if (stdpComboBox.getSelectedItem() != "0") {
			ordersum.append("Sticky Toffee And Date Pudding --- x" + stdpComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (stdpComboBox.getSelectedIndex()));
		}
		if (citComboBox.getSelectedItem() != "0") {
			ordersum.append("Classic Italian Tiramisu --- x" + citComboBox.getSelectedItem().toString() + "\n");
			total += (4.95 * (citComboBox.getSelectedIndex()));
		}
		ordersum.append("------------------------\n");
	}

	public void rs() {
		JOptionPane.showMessageDialog(null, "Your starters are ready and on the way!", "For your information Table 2",
				JOptionPane.INFORMATION_MESSAGE);
	}

	public void rm() {
		JOptionPane.showMessageDialog(null, "Your main courses are ready and on the way!",
				"For your information Table 2", JOptionPane.INFORMATION_MESSAGE);
	}

	public void rd() {
		JOptionPane.showMessageDialog(null, "Your desserts are ready and on the way!", "For your information Table 2",
				JOptionPane.INFORMATION_MESSAGE);
	}

	public void monband(String name) {
		monband.setText(name);
	}

	public void tuesband(String name) {
		tuesband.setText(name);
	}

	public void wedband(String name) {
		wedband.setText(name);
	}

	public void thursband(String name) {
		thursband.setText(name);
	}

	public void friband(String name) {
		friband.setText(name);
	}

	public void satband(String name) {
		satband.setText(name);
	}

	public void sunband(String name) {
		sunband.setText(name);
	}

	public void kitopen() {
		food.setVisible(true);
		kitstatus.setVisible(false);
	}

	public void kitclosed() {
		food.setVisible(false);
		kitstatus.setVisible(true);
	}
}
