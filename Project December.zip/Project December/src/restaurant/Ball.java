package restaurant;

import java.awt.Color;

public class Ball {
	private int Xpos;
	private int Ypos;
	private int size;
	Color col;

	public Ball(int xpos, int ypos, int size, Color col) {
		this.Xpos = xpos;
		this.Ypos = xpos;
		this.size = xpos;
		this.col = col;
	}

	public Color getCol() {
		return col;
	}

	public void setCol(Color col) {
		this.col = col;
	}

	public int getXpos() {
		return Xpos;
	}

	public void setXpos(int xpos) {
		Xpos = xpos;
	}

	public int getYpos() {
		return Ypos;
	}

	public void setYpos(int ypos) {
		Ypos = ypos;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

}
