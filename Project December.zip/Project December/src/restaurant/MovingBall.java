package restaurant;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class MovingBall extends JPanel {
	private int Xpos = 10;
	private int Ypos = 10;
	private int Xpos1 = 200;
	private int Ypos1 = 10;
	private int Xpos2 = 400;
	private int Ypos2 = 10;
	//
	// private int Xpos = 100;
	// private int Ypos = 100;
	// private int Xpos1 = 200;
	// private int Ypos1 = 10;
	// private int Xpos2 = 400;
	// private int Ypos2 = 50;
	//

	ArrayList<Ball> balllist = new ArrayList<Ball>(); // Store all the lines
														// drawn.

	public MovingBall() {
		super();

		ActionListener move = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Xpos = Xpos + 1;
				Ypos = Ypos + 1;
				Xpos2 = Xpos2 - 1;
				Ypos2 = Ypos2 - 1;

				balllist.add(new Ball(Xpos, Ypos, 50, Color.RED));
				balllist.add(new Ball(Xpos1, Ypos1, 50, Color.BLUE));
				balllist.add(new Ball(Xpos2, Ypos2, 50, Color.GREEN));

				repaint();
			}
		};

		Timer tm = new Timer(10, move);
		tm.start();

		//
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		this.setBackground(Color.BLACK);
		for (Ball b : balllist) {
			g.setColor(b.getCol());
			g.fillOval(b.getXpos(), b.getYpos(), b.getSize(), b.getSize());
		}
	}
}
