package restaurant;

public class myRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Kitchen kit = new Kitchen();
		ServerA serA = new ServerA();
		ServerB serB = new ServerB();
		ServerC serC = new ServerC();
		ServerD serD = new ServerD();
		Cashier cashier = new Cashier();

		ServerA.passkit(kit);
		ServerB.passkit(kit);
		ServerC.passkit(kit);
		ServerD.passkit(kit);
		Kitchen.passserA(serA);
		Kitchen.passserB(serB);
		Kitchen.passserC(serC);
		Kitchen.passserD(serD);
	}

}
