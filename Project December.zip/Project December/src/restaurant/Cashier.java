package restaurant;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import javax.crypto.Cipher;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Cashier extends HelloWorldPrinter implements ActionListener {
	final CardLayout cards = new CardLayout();
	// String[] files = null;
	ArrayList<String> files = new ArrayList<String>();
	JPanel cardz = new JPanel();
	JComboBox<Object> tables = new JComboBox<Object>();
	JTextField t1 = new JTextField(2);
	JButton find = new JButton("Find Order");
	JLabel total = new JLabel("The order total is �");
	JTextField t2 = new JTextField(5);
	JButton pay = new JButton("Pay Order");
	JTextArea jta1 = new JTextArea(5, 5);
	JButton lockbut = new JButton("Lock screen");
	JPanel lockpan = new JPanel(new BorderLayout());
	JFrame frame = new JFrame();
	JPanel cp = new JPanel();
	String tablenum;
	String ordernum;
	Double ordertotal;
	String savedrecname;
	int Xpos = 0;
	int Ypos = 0;
	public Cashier() {
		cardz.setLayout(cards);
		find.addActionListener(this);
		pay.addActionListener(this);
		lockbut.addActionListener(this);
		frame.setTitle("Cashier");
		Container cp1 = frame.getContentPane();

		cp.setLayout(new BorderLayout());
		JLabel title = new JLabel("Checkout", 0);
		cp.setBackground(new Color(136, 208, 247));

		title.setFont(new Font("Tahoma", Font.BOLD, 30));
		tables.addItem("1");
		tables.addItem("2");
		tables.addItem("3");
		tables.addItem("4");
		JLabel tablabel = new JLabel("Table: ");
		JLabel tabtop = new JLabel("Select Table below");
		tabtop.setFont(new Font("Tahoma", Font.PLAIN, 18));
		tabtop.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		Box b1 = new Box(BoxLayout.Y_AXIS);
		b1.add(tabtop);
		JPanel p1 = new JPanel(new FlowLayout());
		p1.setBackground(new Color(136, 208, 247));
		p1.add(tablabel);
		p1.add(tables);
		b1.add(p1);
		JPanel p2 = new JPanel(new FlowLayout());
		p2.setBackground(new Color(136, 208, 247));
		JLabel l1 = new JLabel("Input order number");
		p2.add(l1);
		p2.add(t1);
		p2.add(find);
		b1.add(p2);
		JPanel jtapan = new JPanel(new BorderLayout());
		JScrollPane scrollPane = new JScrollPane(jta1);
		jtapan.setSize(200, 200);
		jtapan.add(scrollPane);
		b1.add(jtapan);
		total.setFont(new Font("Tahoma", Font.PLAIN, 18));
		total.setAlignmentX(JComponent.CENTER_ALIGNMENT);
		b1.add(total);
		JPanel p3 = new JPanel(new FlowLayout());
		p3.setBackground(new Color(136, 208, 247));
		JLabel l2 = new JLabel("Input amount of money given:  �");
		l2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		p3.add(l2);
		p3.add(t2);
		b1.add(p3);
		JPanel botpan = new JPanel(new FlowLayout());
		botpan.setBackground(new Color(136, 208, 247));
		botpan.add(pay);
		botpan.add(lockbut);

		b1.add(botpan);
		cp.add(b1, BorderLayout.CENTER);
		cp.add(title, BorderLayout.NORTH);
		
		
		MovingBall ball = new MovingBall();
		cardz.add(ball, "Lock");
		cardz.add(cp, "Home");
		cp1.add(cardz, BorderLayout.CENTER);
		
		ball.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent evt) {
				String password = JOptionPane.showInputDialog(null,
						"Enter password", "Login",
						JOptionPane.INFORMATION_MESSAGE);
				if (password.equals("1234")) {
					File folder1 = new File("reciepts");
					listFilesForFolder(folder1);
					if (files.size() > 0) {
						for (int x = 0; x < files.size(); x++) {
							String key = "This is a secret";
							File inputFile = new File("reciepts/"
									+ files.get(x));
							File decryptedFile = new File("reciepts/"
									+ files.get(x));
							try {
								Cashier.fileProcessor(Cipher.DECRYPT_MODE, key,
										inputFile, decryptedFile);
							} catch (Exception ex) {
								System.out.println(ex.getMessage());
								ex.printStackTrace();
							}
						}
					}
				}
				cards.show(cardz, "Home");
			}
		});
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setSize(600, 500);
	}

	public void checkorder(String x, String y) {
		Scanner in1 = new Scanner(x);
		String words[] = x.split(" ");
		for (int i = 0; i < words.length; i++) {
			jta1.append(words[i] + "\n");
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == find) {
			jta1.setText("");
			tablenum = "Table_" + tables.getSelectedItem().toString();
			ordernum = "Order_" + t1.getText().trim();
			File inputFile = new File("src/restaurant/" + tablenum + ".txt");
			Scanner in = null;
			try {
				in = new Scanner(inputFile);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			int f = 0;
			while (in.hasNextLine()) {
				String value = in.nextLine();
				// checkorder(value, ordernum);
				if (f > 0 && !value.equals("::")) {
					jta1.append(value + "\n");
				} else if (f > 0 && value.equals("::")) {
					break;
				}
				int count = value.indexOf(ordernum);
				if (count > 0) {
					String price = value.substring(count + 17, count + 23);
					total.setText("The order total is �" + price);
					ordertotal = Double.parseDouble(price);
					jta1.append("Order is:\n");
					f++;
				}

			}
		} else if (e.getSource() == pay) {
			DecimalFormat df = new DecimalFormat("#.00");
			double amm = Double.parseDouble(t2.getText());
			int ans = JOptionPane.showConfirmDialog(frame,
					"Are you sure you would like to pay?", "Important",
					JOptionPane.YES_NO_OPTION);
			if (ans == 0) {
				if (amm >= ordertotal) {
					JOptionPane.showMessageDialog(null,
							"The order has been paid for in total, the change due is "
									+ df.format(amm - ordertotal) + " euro ",
							"Confirmation", JOptionPane.INFORMATION_MESSAGE);
					DateFormat dateFormat = new SimpleDateFormat(
							"yyyy/MM/dd HH:mm:ss");
					Date date = new Date();
					String date1 = dateFormat.format(date);
					savedrecname = "reciepts/" + ordernum + tablenum + ".txt";
					try {
						String rec = "The Old Mill\n\n" + date1 + "\n"
								+ jta1.getText() + "\nTotal----" + ordertotal
								+ "\nPaid----" + amm + "\nChange----"
								+ (amm - ordertotal)
								+ "\n\nThank you for your custom!";
						File file = new File(savedrecname);
						PrintWriter out = new PrintWriter(savedrecname);
						out.println(rec);
						out.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					int question = JOptionPane.showConfirmDialog(frame,
							"Do you want a reciept?", "Query",
							JOptionPane.YES_NO_OPTION);
					if (ans == 0) {
						PrinterJob pj = PrinterJob.getPrinterJob();
						if (pj.printDialog()) {
							try {
								pj.print();
							} catch (PrinterException exc) {
								System.out.println(exc);
							}
						}
					}

					jta1.setText("");
					t1.setText("");
					t2.setText("");
					total.setText("The order total is �");

				} else {
					JOptionPane.showMessageDialog(null,
							"Not enough cash given to pay", "Alert",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		} else if (e.getSource() == lockbut) {
			File folder1 = new File("reciepts");
			listFilesForFolder(folder1);
			if (files.size() > 0) {
				for (int x = 0; x < files.size(); x++) {
					String key = "This is a secret";
					File inputFile = new File("reciepts/" + files.get(x));
					File decryptedFile = new File("reciepts/" + files.get(x));
					try {
						Cashier.fileProcessor(Cipher.ENCRYPT_MODE, key,
								inputFile, decryptedFile);
					} catch (Exception ex) {
						System.out.println(ex.getMessage());
						ex.printStackTrace();
					}
				}
			}
			cards.show(cardz, "Lock");
		}

	}

	public void listFilesForFolder(final File folder) {
		int i = 0;
		for (final File fileEntry : folder.listFiles()) {
			files.add(fileEntry.getName());
		}
	}
	public void paintComponent(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillOval(Xpos, Ypos, 10, 10);
		
//		g.setColor(Color.GREEN);
//		g.fillOval(Xpos1, Ypos1, 30, 30);
	}
}
